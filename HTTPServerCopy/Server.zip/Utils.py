def log(msg):
    print(msg)
